#!/bin/bash
ls --color=always -l "$@"|less -R

